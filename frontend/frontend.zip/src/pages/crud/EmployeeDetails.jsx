import React from 'react'

export default function EmployeeDetails() {
  return (
    <div>EmployeeDetails</div>
  )
}
