import React from 'react'
import {BrowserRouter,Route,Routes} from "react-router-dom"
import Navbar from './components/Navbar'
import ContactUs from './pages/ContactUs'
import Home from './pages/Home'

export default function App() {
  return (
    <BrowserRouter>
    <Navbar/>
    <Routes>
      <Route path="/" element={<Home/>} />
      <Route path="/contactus" element={<ContactUs/>} />
    </Routes>
    </BrowserRouter>
  )
}
