import React from 'react'
import { index } from '../index.css'
export default function Home() {
  return (
    <>
      <section className='home-banner'>
        <div className="container">
          <div className="row">
            <div className="col-sm-6 d-flex flex-wrap align-items-center">
              <div className="banner-content">

                <h2 className="banner-title">Creativity drives us towards Perfection</h2>
              </div>
              <div className="banner-text">
                <p>We craft astonishing websites,magnificent high geared Apps for IOS & others, innovation CRM that ensure overall growth of your business.</p>
              </div>
              <div className="banner-button">
                <a href="" className='button-round'>Learn More</a>
                <a href="" className='outline-roundoutline-round-white'>Contact us</a>
              </div>
            </div>
            <div className="col-sm-6 d-flex flex-wrap align-items-center">
              <div className="banner-img">
                  <img src="https://vaanitechlabs.com/public/frontend/assets/resize_image/resize1_home.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>

      </section>
    </>
  )
}
